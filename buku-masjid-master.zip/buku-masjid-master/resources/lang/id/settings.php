<?php

return [
    'settings' => 'Pengaturan',
];
