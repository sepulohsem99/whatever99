<?php

return [
    'settings' => 'Settings',
];
